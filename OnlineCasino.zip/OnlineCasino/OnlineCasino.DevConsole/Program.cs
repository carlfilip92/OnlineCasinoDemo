﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineCasino.ClassLibrary;

namespace OnlineCasino.DevConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //PlayBlackJack();

            var dealer = new BlackJackDealer();

            dealer.Cards = dealer.DealCards(2);

            foreach (var card in dealer.Cards)
            {
                Console.WriteLine(card.Name);
            }

            dealer.Cards = dealer.DealCards(2);

            foreach (var card in dealer.Cards)
            {
                Console.WriteLine(card.Name);
            }

            Console.ReadKey();
        }

        private static void PlayBlackJack()
        {
            var dealer = new BlackJackDealer();

            dealer.Cards = dealer.DealCards(2);
            dealer.TotalBlJValue = 0;

            var player = new Player();

            player.PlayerNumber = 1;
            player.Name = "PLAYER1";
            player.Cards = dealer.DealCards(2);
            player.TotalBlJValue = 0;


            Console.WriteLine("Dealers first card is: " + dealer.Cards[0].Name + "And value is: " + dealer.Cards[0].BlackJackValue.ToString());
            Console.WriteLine(player.Name + "s cards are:");
            Console.WriteLine(player.Cards[0].Name + " And value is: " + player.Cards[0].BlackJackValue.ToString());
            Console.WriteLine(player.Cards[1].Name + " And value is: " + player.Cards[1].BlackJackValue.ToString());

            player.TotalBlJValue = player.Cards[0].BlackJackValue + player.Cards[1].BlackJackValue;

            Console.WriteLine("Players total value is: " + player.TotalBlJValue.ToString());
            Console.WriteLine("Enter 0 for STAY or 1 for HIT:");

            string p1input = Console.Read().ToString();

            if (p1input == "49")
            {
                Console.WriteLine(player.Name + " chose HIT!");

                player.Cards.Add(dealer.DealCards(1)[0]);

                Console.WriteLine(player.Name + "s cards are now:");
                Console.WriteLine(player.Cards[0].Name + " And value is: " + player.Cards[0].BlackJackValue.ToString());
                Console.WriteLine(player.Cards[1].Name + " And value is: " + player.Cards[1].BlackJackValue.ToString());
                Console.WriteLine(player.Cards[2].Name + " And value is: " + player.Cards[2].BlackJackValue.ToString());

                player.TotalBlJValue = player.Cards[0].BlackJackValue + player.Cards[1].BlackJackValue + player.Cards[2].BlackJackValue;

                Console.WriteLine("Players total value is now: " + player.TotalBlJValue.ToString());
            }

            else
            {
                Console.WriteLine("Players total value is still: " + player.TotalBlJValue.ToString());
            }

            Console.WriteLine("Dealers second card is: " + dealer.Cards[1].Name + "And value is: " + dealer.Cards[0].BlackJackValue.ToString());

            dealer.TotalBlJValue = dealer.Cards[0].BlackJackValue + dealer.Cards[1].BlackJackValue;

            Console.WriteLine("Dealers total value is: " + dealer.TotalBlJValue.ToString());

            if (player.TotalBlJValue > 21)
            {
                Console.WriteLine("Dealer wins!");
            }

            else if (dealer.TotalBlJValue > 21)
            {
                Console.WriteLine(player.Name + " wins!");
            }

            else if (player.TotalBlJValue <= 21 && player.TotalBlJValue > dealer.TotalBlJValue)
            {
                Console.WriteLine(player.Name + " wins!");
            }

            else if (player.TotalBlJValue == 21)
            {
                Console.WriteLine(player.Name + " wins!");
            }

            else
            {
                Console.WriteLine("Dealer wins!");
            }

            
        }
    }
}
