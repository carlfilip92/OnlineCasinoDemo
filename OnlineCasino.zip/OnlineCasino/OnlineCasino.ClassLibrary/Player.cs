﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineCasino.ClassLibrary
{
    public class Player
    {
        public int PlayerNumber { get; set; }
        public string Name { get; set; }
        public List<PlayingCard> Cards { get; set; }
        public int Credits { get; set; }
        public int TotalBlJValue { get; set; }

    }
}
