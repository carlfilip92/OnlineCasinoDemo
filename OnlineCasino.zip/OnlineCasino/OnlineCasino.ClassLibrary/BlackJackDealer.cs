﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineCasino.ClassLibrary
{
    public class BlackJackDealer
    {
        public List<PlayingCard> Cards { get; set; }
        public int TotalBlJValue { get; set; }

        public static List<PlayingCard> GetNewDeck()
        {
            var Deck = new List<PlayingCard>();

            string[] Suites = { "Hearts", "Diamonds", "Clubs", "Spades" };

            string[] ColoredCards = { "Jack", "Queen", "King", "Ace" };


            foreach (var suite in Suites)
            {
                for (int i = 2; i <= 10; i++)
                {
                    var card = new PlayingCard();

                    card.Suite = suite;
                    card.Value = i;
                    card.Name = card.Value.ToString() + "of" + card.Suite;
                    card.BlackJackValue = card.Value;
                    card.ImageLink = @"/Images/PlayingCards/" + card.Suite + @"/" + card.Name + ".png";

                    Deck.Add(card);
                }

                int num = 11;

                foreach (var cardname in ColoredCards)
                {

                    var card = new PlayingCard();

                    card.Suite = suite;
                    card.Value = num;
                    card.Name = cardname + "of" + card.Suite;
                    card.BlackJackValue = 10;
                    card.ImageLink = @"/Images/PlayingCards/" + card.Suite+ @"/" + card.Name + ".png";
                    if (card.Name.Contains("Ace"))
                    {
                        card.Value = 1;
                        card.BlackJackValue = 11;
                    }

                    num++;

                    Deck.Add(card);

                }


            }


            return Deck;
        }

        public List<PlayingCard> DealCards(int amount)
        {
            var randomNumberGenerator = new Random();

            var Deck = GetNewDeck();

            var Cards = new List<PlayingCard>();

            Cards.Clear();

            int rnum = 0;

            for(int i = 1; i <= amount; i++)
            {

                rnum = randomNumberGenerator.Next(0, 51);

                Cards.Add(Deck[rnum]);
            }

            return Cards;
        }
    }
}
